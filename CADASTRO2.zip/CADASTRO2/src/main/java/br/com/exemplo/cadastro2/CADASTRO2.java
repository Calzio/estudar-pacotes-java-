/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package br.com.exemplo.cadastro2;

import br.com.exemplo.cadastro2.view.TelaCadastro;

/**
 *
 * @author aluno.den
 */
public class CADASTRO2 {

    public static void main(String[] args) {
        TelaCadastro t  = new TelaCadastro();
        t.setVisible(true);
    }
}
